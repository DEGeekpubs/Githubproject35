_This is an **unsupported preview build** of the `${BRANCH}` branch of AWS Toolkit._

# Install

1. Download the respective plugin zip from the assets below
2. In the IDE, go to Settings -> Plugins
3. Click on Install plugin from disk and select the downloaded zip

# Changes

${AWS_TOOLKIT_CHANGES}
